package com.bdd.actionPages;

import java.util.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.openqa.selenium.interactions.Actions;

public class ProductPage {
	public WebDriver driver;

    public ProductPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    
    @FindBy(xpath = "//button[@title='Brand']")
    protected WebElement xpBrand;
    
    @FindBy(xpath = "//div[contains(@class,'checkbox')]//button[contains(@value,'brand')]")
    protected List<WebElement> xpBrandSelectionCheckBox; 
    @FindBy(xpath = "//div[contains(@class,'c-product-card__image')]//img")
    protected WebElement xpProduct; 
    
    @FindBy(xpath ="//button[@class='c-refine__cta close']")
    protected WebElement xpClose;
    
    @FindBy(xpath = "//button[@class='size-guide-link']")
    protected WebElement xpSizeGuide;
    
    @FindBy(xpath = "//h1[contains(.,'Size Guide')]")
    protected WebElement xpSizeHeader;
    @FindBy(xpath = "//label[contains(.,'16.5')]")
    protected WebElement xpSelectProductSize;
    
    @FindBy(xpath = "//ul[contains(@aria-label,'Quantity')]//li[1]")
    protected WebElement xpSelectQuantity;
    @FindBy(xpath = "//button[@id='addToCartButton']")
    protected WebElement xpAddToCart;
    
    @FindBy(xpath = "//div[@id='miniCart']")
    protected WebElement xpCart;
    @FindBy(xpath = "//div[@class='col-xs-8 details']//a[@class='name brand']")
    protected WebElement xpProductName;
    
    @FindBy(xpath = "//a[contains(@class,'primary mini-cart-checkout-button')]//span['Checkout']")
    protected WebElement xpCheckOutCart;
    public static String parentWindow;
    
    public void clickOnbrand() {
    	xpBrand.click();
    }
    
    public void selectBrandCheckBoxes() {
    	for(int i=1;i<5;i++) {
    		xpBrandSelectionCheckBox.get(i).click();
    	}
    }
    
    public void closeWindow() {
    	xpClose.click();
    }
    public void clickOnProduct() {
    	xpProduct.click();
    }
    
    public void clickOnSizeGuide() {
    	 parentWindow = driver.getWindowHandle();
    	xpSizeGuide.click();
    	String ChildWindow = driver.getWindowHandle();
    	Set<String> windows =driver.getWindowHandles();
    	for(String tab:windows) {
    		if(tab.equals(ChildWindow)) {
    			driver.switchTo().window(ChildWindow);
    		}
    		
    	}
    	
    }
    
    public void VerifySizeGuide(String ExpctedHeader) {
    	String sizeGuideHeader = xpSizeHeader.getText();
    	Assert.assertEquals(ExpctedHeader, sizeGuideHeader);
    	driver.switchTo().window(parentWindow);
    }
    
    public void selectProductSize() {
    	xpSelectProductSize.click();
    
    }
    
    public void SelectQuantity() {
    	xpSelectQuantity.click();
    }

    public void AddToBag() {
    	xpAddToCart.click();
    }
    
    public void hoverToCartBag() {
    	Actions action = new Actions(driver);
    	action.moveToElement(xpCart).perform();
    }
    public void verifyProductDetails(String ExpctedProdName) {
    	String ProductName = xpProductName.getText();
    	Assert.assertEquals(ProductName,ExpctedProdName );
    }
    
    	
    
    public void ClickOnCheckOutCart() {
    	Actions action = new Actions(driver);
    	action.moveToElement(xpCart).perform();
    	xpCheckOutCart.click();
    }
}
