package com.bdd.actionPages;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.*;

import org.openqa.selenium.interactions.*;

import java.util.*;

public class HomePage extends BaseClass {
    public WebDriver driver;

    
    @FindBy(xpath = "(//a[@title='Men'][normalize-space()='Men'])[2]")
    protected WebElement xpMenCollection;
    @FindBy(xpath ="//nav[@role ='navigation']//ul[contains(@class,'main-navigation-list')]//li[contains(@data-categoryparent,'Departments')]")
    protected List<WebElement> xptopMenu;
    @FindBy(xpath ="//*[@id='MenCategoryLink']//button[contains(.,'Clothing')]")
    protected WebElement xpClothing;
    @FindBy(xpath ="//div[@id='MenClothingMMNode']//li[@data-category='View All']")
    protected WebElement xpviewAll;
    
    public HomePage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    
    //Actions action = new Actions(driver);
    public void HoverToMenuTabs(WebDriver driver) {
    	Actions action = new Actions(driver);
    	for(WebElement e:xptopMenu) {
    		action.moveToElement(e).perform();
    		//thread.sleep(3000);
    	}
    	System.out.println("Landend on home page");
    	
    	
    }
    
	
	  public void hoverOnMenTab() {
		  Actions action = new Actions(driver);
	  action.moveToElement(xpMenCollection).perform(); 
	  }
	  
	  public void hoverOnClothing() {
		  Actions action = new Actions(driver);
	  action.moveToElement(xpClothing).perform();
	  }
	 
    public void clickOnViewAll() {
    	try {
    	xpviewAll.click();
    	Thread.sleep(5000);
    }catch(Exception e) {
    	
    }
    }
}


