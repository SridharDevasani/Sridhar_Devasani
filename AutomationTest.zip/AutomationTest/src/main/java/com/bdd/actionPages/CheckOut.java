package com.bdd.actionPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class CheckOut {
	public WebDriver driver;

    public CheckOut(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    
    @FindBy(xpath = "//a[@aria-controls='loginAsGuest']")
    protected WebElement xpCheckOutAsGuest;
    
    @FindBy(xpath = "//button[@id='checkoutLoginSubmit']")
    protected WebElement xpSubmitCheckOutAsGuest;
    
    @FindBy(xpath = "//div[@class='help-block']//span")
    protected WebElement xpErrorMsg;
    
    public void clickOnCheckOutAsGuest() {
    	xpCheckOutAsGuest.click();
    }
    
    public void submitAsCheckOutAsGuest() {
    	xpSubmitCheckOutAsGuest.click();
    }
    
    public void verifyErrorMsg(String ExpectedErrorMsg) {
    	String error = xpErrorMsg.getText();
   
    	Assert.assertEquals(error, ExpectedErrorMsg);
    }
}
