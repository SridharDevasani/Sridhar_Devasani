package com.bdd.stepdefinition;

import com.bdd.actionPages.APITest;

import com.bdd.actionPages.BaseClass;
import com.bdd.actionPages.HomePage;
import com.bdd.actionPages.ProductPage;
import com.bdd.actionPages.CheckOut;

import cucumber.api.java.en.*;





public class HomePageStepdefs extends BaseClass {
	HomePage homePage = new HomePage(driver);
	ProductPage prodctpage = new ProductPage(driver);
	CheckOut checkout = new CheckOut(driver);
   APITest apiTest = new APITest();



    public HomePageStepdefs(){
        super();
        }

    @Given("user on TKMaxx home page")
    public void user_on_TKMaxx_home_page() {
    	homePage.HoverToMenuTabs(driver);
    }
     
    @When("user hover over men tab")
    public void user_hover_over_men_tab() {
    	
    	homePage.hoverOnMenTab();
    }
    
    @And("user hover over clothing")
    public void user_hover_over_clothing() {
    	homePage.hoverOnClothing();
    }
    
    @And("user click on viewAll link")
    public void user_click_on_viewAll_link() {
    	homePage.clickOnViewAll();
    }
    
    @And("user select multiple checkBoxes")
    public void user_select_multiple_checkBoxes() {
    	prodctpage.clickOnbrand();
    	prodctpage.selectBrandCheckBoxes();
    	prodctpage.closeWindow();
  	
    }
    
    @And("user click on product from the search results")
    public void user_click_on_product_from_the_search_results() {
    	prodctpage.clickOnProduct();	
    }
    
    @And("user click on size guide link")
    public void user_click_on_size_guide_link() {
    	prodctpage.clickOnSizeGuide();
    	
    }
    @Then("user verify the page contains the text {string}")
    public void verify_the_page_contains_the_text(String ExpectedHeader) {
    	prodctpage.VerifySizeGuide(ExpectedHeader);
    	
    }
    
    
    
    @And("user select a size and quantity from the drop down")
    public void user_select_a_size_and_quantity_from_the_drop_down() {
    	prodctpage.selectProductSize();
    	prodctpage.SelectQuantity();
    }
    
    @And("user click on the Add to bag button")
    public void user_click_on_the_Add_to_bag_button() {
    	prodctpage.AddToBag();
    }
    
    @And("user hover on the view Bag button")
    public void user_hover_on_the_view_Bag_button() {
    	prodctpage.hoverToCartBag();
    	
    }
    
    @Then("user able to see {string} in selected product")
    public void user_able_to_see_in_selected_product(String product) {
    	prodctpage.verifyProductDetails(product);
    }
    
    @And("user click on checkout button")
    public void user_click_on_checkout_button() {
    	
    	prodctpage.ClickOnCheckOutCart();
    }
    @And("user click on Checkout as a guest button")
    public void user_click_on_Checkout_as_a_guest_button() {
    	checkout.clickOnCheckOutAsGuest();
    }
    @Then("user should be able to see error msg as {string}")
    public void user_should_be_able_to_see_error_msg_as(String errormsg) {
    	checkout.submitAsCheckOutAsGuest();
    	checkout.verifyErrorMsg(errormsg);
    	
    }
    
    

}
